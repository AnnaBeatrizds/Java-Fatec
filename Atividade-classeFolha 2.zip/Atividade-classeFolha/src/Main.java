public class Main {
    public static void main(String[] args) {
        Consulta consulta1 = new Consulta();
        Consulta consulta2 = new Consulta();

        consulta1.setData("2023-10-17");
        System.out.println("Data da consulta 1: " + consulta1.getData());
        consulta1.realizarConsulta();

        consulta2.setHora("10:00");
        System.out.println("Hora da consulta 2: " + consulta2.getHora());
        consulta2.agendamento();

        Site site1 = new Site();
        Site site2 = new Site();

        site1.setLinguagem("HTML, CSS, JavaScript");
        System.out.println("Linguagem do site 1: " + site1.getLinguagem());
        site1.busca();


        site2.setLayout("Clássico");
        System.out.println("Layout do site 2: " + site2.getLayout());
        site2.realizarCompra();

        Sitio sitio1 = new Sitio();
        Sitio sitio2 = new Sitio();

        sitio1.setTamanho(1000.0);
        System.out.println("Tamanho do sítio 1: " + sitio1.getTamanho());
        sitio1.morar();

        sitio2.setLocalizacao("Zona urbana");
        System.out.println("Localização do sítio 2: " + sitio2.getLocalizacao());
        sitio2.cultivar();

        ContaBancaria conta1 = new ContaBancaria();
        ContaBancaria conta2 = new ContaBancaria();

        conta1.setBanco("Banco X");
        System.out.println("Banco da conta 1: " + conta1.getBanco());
        conta1.realizarSaque();

        conta2.setNumeroConta("987654321");
        System.out.println("Número de conta da conta 2: " + conta2.getNumeroConta());
        conta2.realizarDeposito();

        Vestido vestido1 = new Vestido();
        Vestido vestido2 = new Vestido();

        vestido1.setCor("Azul");
        System.out.println("Cor do vestido 1: " + vestido1.getCor());

        vestido2.setPreco(79.99);
        System.out.println("Preço do vestido 2: " + vestido2.getPreco());

        Coringa coringa1 = new Coringa();
        Coringa coringa2 = new Coringa();

        coringa1.setSaudeMental(false);
        coringa1.setPalhaco(true);

        System.out.println("É um palhaço? " + coringa1.isPalhaco());
        System.out.println("Tem saúde mental? " + coringa1.isSaudeMental());
        coringa1.causarCaos();

        coringa2.setSaudeMental(true);
        coringa2.setPalhaco(false);
        System.out.println("É um palhaço? " + coringa2.isPalhaco());
        System.out.println("Tem saúde mental? " + coringa2.isSaudeMental());
        coringa2.cometerCrimes();

        Robo robo1 = new Robo();
        Robo robo2 = new Robo();

        robo1.setMaterial("Aço");
        System.out.println("Material do robô 1: " + robo1.getMaterial());
        robo1.operarAcao();


        robo2.setMemoria("32GB");
        System.out.println("Memória do robô 2: " + robo2.getMemoria());
        robo2.operarAcao();

        Calca calca1 = new Calca();
        Calca calca2 = new Calca();

        calca1.setCor("Preto");
        calca1.setPreco(49.99);
        System.out.println("Cor da calça 1: " + calca1.getCor());
        System.out.println("Preço da calça 1: " + calca1.getPreco());

        calca2.setTamanho("M");
        calca2.setMarca("Marca Z");
        System.out.println("Tamanho da calça 2: " + calca2.getTamanho());
        System.out.println("Marca da calça 2: " + calca2.getMarca());

        Porta porta1 = new Porta();
        Porta porta2 = new Porta();

        porta1.setTamanho("80x200 cm");
        System.out.println("Tamanho da porta 1: " + porta1.getTamanho());
        porta1.abrir();

        porta2.setCor("Marrom");
        System.out.println("Cor da porta 2: " + porta2.getCor());
        porta2.fechar();

        Agendamento agendamento1 = new Agendamento();
        Agendamento agendamento2 = new Agendamento();

        agendamento1.setData("2023-10-18");
        System.out.println("Data do agendamento 1: " + agendamento1.getData());
        agendamento1.verificarDisponibilidade();


        agendamento2.setHora("11:30");
        System.out.println("Hora do agendamento 2: " + agendamento2.getHora());
        agendamento2.verificarDisponibilidade();
    }
}
