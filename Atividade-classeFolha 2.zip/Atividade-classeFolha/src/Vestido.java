public class Vestido {
    private String cor;
    private double preco;

    public double getPreco() {

        return preco;
    }

    public void setPreco(double preco) {

        this.preco = preco;
    }

    public String getCor() {

        return cor;
    }

    public void setCor(String cor) {

        this.cor = cor;
    }

    public void setPreço(double v) {
        this.preco = preco;
    }
}
