public class ContaBancaria {
    private String banco;
    private String numeroConta;

    public void realizarSaque() {

        System.out.println("Realizando saque na conta bancária.");
    }

    public void realizarDeposito() {

        System.out.println("Realizando depósito na conta bancária.");
    }

    public void setBanco(String bancoX) {

        this.banco = banco;
    }

    public String getBanco() {
        return banco;
    }

    public void setNumeroConta(String number) {
        this.numeroConta = numeroConta;
    }

    public String getNumeroConta() {
        return numeroConta;
    }

    public void realizarDepósito() {

    }
}