public class Site {
    private String linguagem;
    private String layout;

    public void busca() {
        System.out.println("Realizando busca no site.");
    }

    public void realizarCompra() {
        System.out.println("Realizando compra no site.");
    }

    public void setLinguagem(String s) {
        this.linguagem = linguagem;
    }

    public String getLinguagem() {
        return linguagem;
    }

    public void setLayout(String responsivo) {
        this.layout = layout;
    }


    public String getLayout() {
        return layout;
    }
}