public class Calca {
    private String cor;
    private double preco;
    private String tamanho;
    private String marca;

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public void setTamanho(String m) {
       this.tamanho = tamanho;
    }

    public void setMarca(String marcaZ) {
        this.marca = marca;
    }

    public String getTamanho() {
        return tamanho;
    }

    public String getMarca() {
        return marca;
    }
}