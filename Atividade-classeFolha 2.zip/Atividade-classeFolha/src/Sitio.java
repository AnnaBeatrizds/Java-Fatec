public class Sitio {
    private double tamanho;
    private String localizacao;

    public void morar() {
        System.out.println("Morando no sítio.");
    }

    public void cultivar() {
        System.out.println("Cultivando no sítio.");
    }

    public void setTamanho(double v) {
        this.tamanho = tamanho;
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setLocalizacao(String zonaRural) {

    }

    public String getLocalizacao() {
        return localizacao;
    }
}