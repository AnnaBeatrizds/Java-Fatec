public class Consulta {
    private String data;
    private String hora;

    public void realizarConsulta() {

        System.out.println("Realizando consulta médica.");
    }

    public void agendamento() {

        System.out.println("Agendando consulta médica.");
    }

    public int quantidadeConsultas() {
        return 5;
    }

    public void setData(String date) {
        this.data = data;
    }

    public void setHora(String time) {
        this.hora = hora;
    }

    public String getData() {
        return data;
    }

    public String getHora() {
        return hora;
    }
}
