public class Coringa {
    private boolean palhaco;
    private boolean saudeMental;

    public void causarCaos() {
        System.out.println("Causando o caos como o Coringa.");
    }

    public void cometerCrimes() {
        System.out.println("Cometendo crimes como o Coringa.");
    }

    // Getters e Setters
    public boolean isPalhaco() {
        return palhaco;
    }

    public void setPalhaco(boolean palhaco) {
        this.palhaco = palhaco;
    }

    public boolean isSaudeMental() {
        return saudeMental;
    }

    public void setSaudeMental(boolean saudeMental) {
        this.saudeMental = saudeMental;
    }
}
