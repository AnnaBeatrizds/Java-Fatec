public class Robo {
    private String material;
    private String memoria;

    public void operarAcao() {

        System.out.println("Operando ação como um robô.");
    }

    public void setMaterial(String aço) {
        this.material = material;
    }

    public void setMemoria(String s) {
        this.memoria = memoria;
    }

    public String getMaterial() {
        return material;
    }

    public String getMemoria() {
        return memoria;
    }
}
