public class Agendamento {
    private String data;
    private String hora;

    public void verificarDisponibilidade() {
        System.out.println("Verificando a disponibilidade de agendamento.");
    }

    public void setData(String date) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setHora(String time) {
        this.hora = hora;
    }

    public String getHora() {
        return hora;
    }
}
