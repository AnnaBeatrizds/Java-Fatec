public class Porta {
    private String tamanho;
    private String cor;

    public void abrir() {
        System.out.println("Abrindo a porta.");
    }

    public void fechar() {
        System.out.println("Fechando a porta.");
    }

    public void setTamanho(String s) {
        this.tamanho = tamanho;
    }

    public void setCor(String marrom) {
        this.cor = cor;
    }

    public String getTamanho() {
        return  tamanho;
    }

    public String getCor() {
        return cor;
    }
}